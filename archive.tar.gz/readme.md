# Python File Compression
## Create Tar & Tar.gz files

### Sample Output
'''
Deleted old archive.tar
Deleted old archive.tar.gz
Created archive.tar
Created archive.tar.gz
Compression Complete!
Original Directory File Size: 28.0 MB
Tar File Size: 19.8 MB - Compression : 70.9327368819292 % 
Tar.gz File Size: 8.1 MB - Compression : 29.042098108628977 % 
['archive.tar', 'archive.tar.gz', 'bar', 'conversion.py', 'foo', 'quux', 'venv']
'''